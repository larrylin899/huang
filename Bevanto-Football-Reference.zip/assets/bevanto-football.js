(()=>{
  const initialize=(scope=document)=>{
    scope.querySelectorAll('[data-bv-carousel]').forEach(section=>{
      if(section.dataset.bvReady)return;section.dataset.bvReady='true';
      const track=section.querySelector('[data-bv-track]');
      const previous=section.querySelector('[data-bv-prev]'),next=section.querySelector('[data-bv-next]');
      if(!track||!previous||!next)return;
      const update=()=>{previous.disabled=track.scrollLeft<=2;next.disabled=track.scrollLeft+track.clientWidth>=track.scrollWidth-2;};
      const advance=direction=>{const first=track.firstElementChild;if(!first)return;const step=first.getBoundingClientRect().width+(parseFloat(getComputedStyle(track).columnGap)||0);track.scrollBy({left:direction*step,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});};
      previous.addEventListener('click',()=>advance(-1));next.addEventListener('click',()=>advance(1));track.addEventListener('scroll',update,{passive:true});new ResizeObserver(update).observe(track);update();
    });
    scope.querySelectorAll('[data-bv-motion]').forEach(button=>{
      if(button.dataset.bvReady)return;button.dataset.bvReady='true';
      button.addEventListener('click',()=>{const paused=document.body.classList.toggle('bv-motion-paused');button.setAttribute('aria-pressed',String(paused));button.setAttribute('aria-label',paused?'Resume moving banners':'Pause moving banners');button.textContent=paused?'▶':'Ⅱ';});
    });
  };
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>initialize());else initialize();
  document.addEventListener('shopify:section:load',event=>initialize(event.target));
  document.addEventListener('keydown',event=>{if(event.key!=='Escape')return;const details=event.target.closest('.bv-team-menu[open],.bv-mobile-menu[open]');if(details){details.open=false;details.querySelector('summary')?.focus();}});
  document.addEventListener('click',event=>{document.querySelectorAll('.bv-desktop-navigation .bv-team-menu[open]').forEach(details=>{if(!details.contains(event.target))details.open=false;});});
})();
