(() => {
  const initialized = new WeakSet();
  function setup(root = document) {
    root.querySelectorAll('[data-fa-header]').forEach(header => {
      if (initialized.has(header)) return;
      initialized.add(header);
      let opener;
      header.querySelectorAll('[data-fa-open]').forEach(button => button.addEventListener('click', () => {
        const dialog = header.querySelector(`[data-fa-dialog="${button.dataset.faOpen}"]`);
        if (!dialog || dialog.open) return;
        opener = button;
        dialog.showModal(); button.setAttribute('aria-expanded', 'true');
        if (button.dataset.faOpen === 'search') dialog.querySelector('input[type="search"]')?.focus();
      }));
      header.querySelectorAll('[data-fa-dialog]').forEach(dialog => {
        dialog.querySelector('[data-fa-close]')?.addEventListener('click', () => dialog.close());
        dialog.addEventListener('click', event => {
          const rect = dialog.getBoundingClientRect();
          if (event.target === dialog && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) dialog.close();
        });
        dialog.addEventListener('close', () => { opener?.setAttribute('aria-expanded', 'false'); opener?.focus(); });
      });
      header.querySelectorAll('.fa-mega').forEach(details => details.addEventListener('toggle', () => {
        if (details.open) header.querySelectorAll('.fa-mega').forEach(other => { if (other !== details) other.open = false; });
      }));
      header.addEventListener('keydown', event => {
        if (event.key === 'Escape') header.querySelectorAll('.fa-mega[open]').forEach(details => { details.open = false; details.querySelector('summary')?.focus(); });
      });
    });
    root.querySelectorAll('[data-fa-categories]').forEach(section => {
      if (initialized.has(section)) return;
      initialized.add(section);
      const activate = link => {
        section.querySelectorAll('[data-fa-category]').forEach(other => other.classList.toggle('is-active', other === link));
        section.querySelectorAll('[data-fa-frame]').forEach(frame => frame.classList.toggle('is-active', frame.dataset.faFrame === link.dataset.faCategory));
      };
      section.querySelectorAll('[data-fa-category]').forEach(link => {
        link.addEventListener('pointerenter', () => activate(link));
        link.addEventListener('focus', () => activate(link));
      });
    });
    root.querySelectorAll('.fa-products').forEach(section => {
      if (initialized.has(section)) return;
      initialized.add(section);
      const rail = section.querySelector('[data-fa-rail]');
      if (!rail) return;
      const move = direction => rail.scrollBy({ left: direction * rail.clientWidth * .8, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' });
      section.querySelector('[data-fa-prev]')?.addEventListener('click', () => move(-1));
      section.querySelector('[data-fa-next]')?.addEventListener('click', () => move(1));
    });
    root.querySelectorAll('.fa-footer').forEach(footer => {
      if (initialized.has(footer)) return;
      initialized.add(footer);
      const media = matchMedia('(max-width: 749px)');
      const sync = () => footer.querySelectorAll('[data-fa-footer-detail]').forEach(details => { details.open = !media.matches; });
      sync(); media.addEventListener('change', sync);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setup()); else setup();
  document.addEventListener('shopify:section:load', () => setup());
  document.addEventListener('cart:update', event => {
    const count = event.detail?.resource?.item_count;
    if (typeof count !== 'number') return;
    document.querySelectorAll('[data-fa-count]').forEach(badge => { badge.textContent = String(count); badge.hidden = count === 0; });
  });
})();
document.addEventListener('click',event=>{const button=event.target.closest('[data-fa-pause]');if(!button)return;const track=button.closest('.fa-ticker')?.querySelector('[data-fa-ticker]');if(!track)return;const paused=track.classList.toggle('is-paused');button.setAttribute('aria-pressed',String(paused));button.setAttribute('aria-label',paused?'Resume scrolling messages':'Pause scrolling messages');button.textContent=paused?'▶':'II';});
