(() => {
  const initialized = new WeakSet();
  function setup(root = document) {
    root.querySelectorAll('[data-ms-header]').forEach(header => {
      if (initialized.has(header)) return;
      initialized.add(header);
      let opener;
      header.querySelectorAll('[data-ms-open]').forEach(button => button.addEventListener('click', () => {
        const dialog = header.querySelector(`[data-ms-dialog="${button.dataset.msOpen}"]`);
        if (!dialog || dialog.open) return;
        opener = button;
        dialog.showModal(); button.setAttribute('aria-expanded', 'true');
        if (button.dataset.msOpen === 'search') dialog.querySelector('input[type="search"]')?.focus();
      }));
      header.querySelectorAll('[data-ms-dialog]').forEach(dialog => {
        dialog.querySelector('[data-ms-close]')?.addEventListener('click', () => dialog.close());
        dialog.addEventListener('click', event => {
          const rect = dialog.getBoundingClientRect();
          if (event.target === dialog && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) dialog.close();
        });
        dialog.addEventListener('close', () => { opener?.setAttribute('aria-expanded', 'false'); opener?.focus(); });
      });
      header.querySelectorAll('.ms-mega').forEach(details => details.addEventListener('toggle', () => {
        if (details.open) header.querySelectorAll('.ms-mega').forEach(other => { if (other !== details) other.open = false; });
      }));
      header.addEventListener('keydown', event => {
        if (event.key === 'Escape') header.querySelectorAll('.ms-mega[open]').forEach(details => { details.open = false; details.querySelector('summary')?.focus(); });
      });
    });
    root.querySelectorAll('[data-ms-categories]').forEach(section => {
      if (initialized.has(section)) return;
      initialized.add(section);
      const activate = link => {
        section.querySelectorAll('[data-ms-category]').forEach(other => other.classList.toggle('is-active', other === link));
        section.querySelectorAll('[data-ms-frame]').forEach(frame => frame.classList.toggle('is-active', frame.dataset.msFrame === link.dataset.msCategory));
      };
      section.querySelectorAll('[data-ms-category]').forEach(link => {
        link.addEventListener('pointerenter', () => activate(link));
        link.addEventListener('focus', () => activate(link));
      });
    });
    root.querySelectorAll('.ms-products').forEach(section => {
      if (initialized.has(section)) return;
      initialized.add(section);
      const rail = section.querySelector('[data-ms-rail]');
      if (!rail) return;
      const move = direction => rail.scrollBy({ left: direction * rail.clientWidth * .8, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' });
      section.querySelector('[data-ms-prev]')?.addEventListener('click', () => move(-1));
      section.querySelector('[data-ms-next]')?.addEventListener('click', () => move(1));
    });
    root.querySelectorAll('.ms-footer').forEach(footer => {
      if (initialized.has(footer)) return;
      initialized.add(footer);
      const media = matchMedia('(max-width: 749px)');
      const sync = () => footer.querySelectorAll('[data-ms-footer-detail]').forEach(details => { details.open = !media.matches; });
      sync(); media.addEventListener('change', sync);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setup()); else setup();
  document.addEventListener('shopify:section:load', () => setup());
  document.addEventListener('cart:update', event => {
    const count = event.detail?.resource?.item_count;
    if (typeof count !== 'number') return;
    document.querySelectorAll('[data-ms-count]').forEach(badge => { badge.textContent = String(count); badge.hidden = count === 0; });
  });
})();
