/**
 * Local theme utilities and web components (Dawn-compatible).
 */

function getFocusableElements(container) {
  return Array.from(
    container.querySelectorAll(
      "summary, a[href], button:enabled, [tabindex]:not([tabindex^='-']), [draggable], area, input:not([type='hidden']):enabled, select:enabled, textarea:enabled, object, iframe"
    )
  );
}

const trapFocusHandlers = {};

function trapFocus(container, elementToFocus = container) {
  if (!container) return;
  var elements = getFocusableElements(container);
  var first = elements[0];
  var last = elements[elements.length - 1];

  removeTrapFocus();

  trapFocusHandlers.focusin = (event) => {
    if (event.target !== container && event.target !== last && event.target !== first) return;
    document.addEventListener('keydown', trapFocusHandlers.keydown);
  };

  trapFocusHandlers.focusout = function () {
    document.removeEventListener('keydown', trapFocusHandlers.keydown);
  };

  trapFocusHandlers.keydown = function (event) {
    if (event.code.toUpperCase() !== 'TAB') return;
    if (event.target === last && !event.shiftKey) {
      event.preventDefault();
      first.focus();
    }
    if ((event.target === container || event.target === first) && event.shiftKey) {
      event.preventDefault();
      last.focus();
    }
  };

  document.addEventListener('focusout', trapFocusHandlers.focusout);
  document.addEventListener('focusin', trapFocusHandlers.focusin);

  elementToFocus.focus();

  if (
    elementToFocus.tagName === 'INPUT' &&
    ['search', 'text', 'email', 'url'].includes(elementToFocus.type) &&
    elementToFocus.value
  ) {
    elementToFocus.setSelectionRange(0, elementToFocus.value.length);
  }
}

function removeTrapFocus(elementToFocus = null) {
  document.removeEventListener('focusin', trapFocusHandlers.focusin);
  document.removeEventListener('focusout', trapFocusHandlers.focusout);
  document.removeEventListener('keydown', trapFocusHandlers.keydown);
  if (elementToFocus) elementToFocus.focus();
}

function pauseAllMedia() {
  document.querySelectorAll('.js-youtube').forEach((video) => {
    video.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
  });
  document.querySelectorAll('.js-vimeo').forEach((video) => {
    video.contentWindow.postMessage('{"method":"pause"}', '*');
  });
  document.querySelectorAll('video').forEach((video) => video.pause());
  document.querySelectorAll('product-model').forEach((model) => {
    if (model.modelViewerUI) model.modelViewerUI.pause();
  });
}

window.pauseAllMedia = pauseAllMedia;

function onKeyUpEscape(event) {
  if (event.code.toUpperCase() !== 'ESCAPE') return;
  const openDetailsElement = event.target.closest('details[open]');
  if (!openDetailsElement) return;
  const summaryElement = openDetailsElement.querySelector('summary');
  openDetailsElement.removeAttribute('open');
  summaryElement.setAttribute('aria-expanded', false);
  summaryElement.focus();
}

function debounce(fn, wait) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), wait);
  };
}

function throttle(fn, delay) {
  let lastCall = 0;
  return function (...args) {
    const now = new Date().getTime();
    if (now - lastCall < delay) return;
    lastCall = now;
    return fn(...args);
  };
}

function fetchConfig(type = 'json') {
  return {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: `application/${type}` },
  };
}

if (typeof window.Shopify === 'undefined') {
  window.Shopify = {};
}

Shopify.bind = function (fn, scope) {
  return function () {
    return fn.apply(scope, arguments);
  };
};

Shopify.setSelectorByValue = function (selector, value) {
  for (var i = 0, count = selector.options.length; i < count; i++) {
    var option = selector.options[i];
    if (value == option.value || value == option.innerHTML) {
      selector.selectedIndex = i;
      return i;
    }
  }
};

Shopify.addListener = function (target, eventName, callback) {
  target.addEventListener
    ? target.addEventListener(eventName, callback, false)
    : target.attachEvent('on' + eventName, callback);
};

Shopify.postLink = function (path, options) {
  options = options || {};
  var method = options['method'] || 'post';
  var params = options['parameters'] || {};
  var form = document.createElement('form');
  form.setAttribute('method', method);
  form.setAttribute('action', path);
  for (var key in params) {
    var hiddenField = document.createElement('input');
    hiddenField.setAttribute('type', 'hidden');
    hiddenField.setAttribute('name', key);
    hiddenField.setAttribute('value', params[key]);
    form.appendChild(hiddenField);
  }
  document.body.appendChild(form);
  form.submit();
  document.body.removeChild(form);
};

Shopify.CountryProvinceSelector = function (country_domid, province_domid, options) {
  this.countryEl = document.getElementById(country_domid);
  this.provinceEl = document.getElementById(province_domid);
  this.provinceContainer = document.getElementById(options['hideElement'] || province_domid);
  Shopify.addListener(this.countryEl, 'change', Shopify.bind(this.countryHandler, this));
  this.initCountry();
  this.initProvince();
};

Shopify.CountryProvinceSelector.prototype = {
  initCountry: function () {
    var value = this.countryEl.getAttribute('data-default');
    Shopify.setSelectorByValue(this.countryEl, value);
    this.countryHandler();
  },
  initProvince: function () {
    var value = this.provinceEl.getAttribute('data-default');
    if (value && this.provinceEl.options.length > 0) {
      Shopify.setSelectorByValue(this.provinceEl, value);
    }
  },
  countryHandler: function () {
    var opt = this.countryEl.options[this.countryEl.selectedIndex];
    var raw = opt.getAttribute('data-provinces');
    var provinces = JSON.parse(raw);
    this.clearOptions(this.provinceEl);
    if (provinces && provinces.length == 0) {
      this.provinceContainer.style.display = 'none';
    } else {
      for (var i = 0; i < provinces.length; i++) {
        var opt = document.createElement('option');
        opt.value = provinces[i][0];
        opt.innerHTML = provinces[i][1];
        this.provinceEl.appendChild(opt);
      }
      this.provinceContainer.style.display = '';
    }
  },
  clearOptions: function (selector) {
    while (selector.firstChild) selector.removeChild(selector.firstChild);
  },
  setOptions: function (selector, values) {
    for (var i = 0; i < values.length; i++) {
      var opt = document.createElement('option');
      opt.value = values[i];
      opt.innerHTML = values[i];
      selector.appendChild(opt);
    }
  },
};

if (!customElements.get('quantity-input')) {
  class QuantityInput extends HTMLElement {
    constructor() {
      super();
      this.input = this.querySelector('input');
      this.changeEvent = new Event('change', { bubbles: true });
      if (!this.input) return;
      this.input.addEventListener('change', this.onInputChange.bind(this));
      this.querySelectorAll('button').forEach((button) =>
        button.addEventListener('click', this.onButtonClick.bind(this))
      );
    }

    quantityUpdateUnsubscriber = undefined;

    connectedCallback() {
      this.validateQtyRules();
      this.quantityUpdateUnsubscriber = subscribe(PUB_SUB_EVENTS.quantityUpdate, this.validateQtyRules.bind(this));
    }

    disconnectedCallback() {
      if (this.quantityUpdateUnsubscriber) this.quantityUpdateUnsubscriber();
    }

    onInputChange() {
      this.validateQtyRules();
    }

    onButtonClick(event) {
      event.preventDefault();
      const previousValue = this.input.value;
      event.target.name === 'plus' ? this.input.stepUp() : this.input.stepDown();
      if (previousValue !== this.input.value) this.input.dispatchEvent(this.changeEvent);
    }

    validateQtyRules() {
      if (!this.input) return;
      const value = parseInt(this.input.value);
      if (this.input.min) {
        const min = parseInt(this.input.min);
        const buttonMinus = this.querySelector(".quantity__button[name='minus']");
        if (buttonMinus) buttonMinus.classList.toggle('disabled', value <= min);
      }
      if (this.input.max) {
        const max = parseInt(this.input.max);
        const buttonPlus = this.querySelector(".quantity__button[name='plus']");
        if (buttonPlus) buttonPlus.classList.toggle('disabled', value >= max);
      }
    }
  }

  customElements.define('quantity-input', QuantityInput);
}

if (!customElements.get('variant-selects')) {
  class VariantSelects extends HTMLElement {
    constructor() {
      super();
      this.addEventListener('change', this.onVariantChange.bind(this));
    }

    onVariantChange(event) {
      this.updateOptions();
      this.updateMasterId();
      this.updateSelectedSwatchValue(event);
      this.toggleAddButton(true, '', false);
      this.updatePickupAvailability();
      this.removeErrorMessage();
      this.updateVariantStatuses();

      if (!this.currentVariant) {
        this.toggleAddButton(true, '', true);
        this.setUnavailable();
      } else {
        this.updateMedia();
        this.updateURL();
        this.updateVariantInput();
        this.renderProductInfo();
        this.updateShareUrl();
      }
    }

    updateOptions() {
      // Theme uses .product-form__input wrappers with select OR radio pills/swatches (not fieldsets).
      const containers = Array.from(this.querySelectorAll('.product-form__input')).filter((el) => {
        if (el.classList.contains('hidden')) return false;
        const type = el.querySelector('.product-form__input__type')?.dataset?.type;
        return type !== 'hidden';
      });

      if (containers.length) {
        this.options = containers
          .map((element) => {
            const select = element.querySelector('select');
            if (select) return select.value;
            const checked = element.querySelector('input[type="radio"]:checked');
            if (checked) return checked.value;
            return undefined;
          })
          .filter((value) => value !== undefined);
        return;
      }

      // Fallback for Dawn-style markup
      this.options = Array.from(this.querySelectorAll('select, fieldset'), (element) => {
        if (element.tagName === 'SELECT') return element.value;
        if (element.tagName === 'FIELDSET') {
          return Array.from(element.querySelectorAll('input')).find((radio) => radio.checked)?.value;
        }
      }).filter((value) => value !== undefined);
    }

    updateMasterId() {
      this.currentVariant = this.getVariantData().find((variant) => {
        return !variant.options
          .map((option, index) => this.options[index] === option)
          .includes(false);
      });
    }

    updateSelectedSwatchValue({ target }) {
      if (!target) return;
      const { name, value, tagName } = target;
      if (tagName === 'SELECT' && target.selectedOptions.length) {
        const swatchValue = target.selectedOptions[0].dataset.optionSwatchValue;
        const selectedDropdownSwatchValue = this.querySelector(`[data-selected-dropdown-swatch="${name}"] > .swatch`);
        if (!selectedDropdownSwatchValue) return;
        if (swatchValue) {
          selectedDropdownSwatchValue.style.setProperty('--swatch--background', swatchValue);
          selectedDropdownSwatchValue.classList.remove('swatch--unavailable');
        } else {
          selectedDropdownSwatchValue.style.setProperty('--swatch--background', 'unset');
          selectedDropdownSwatchValue.classList.add('swatch--unavailable');
        }
      } else if (tagName === 'INPUT' && target.type === 'radio') {
        const selectedSwatchValue = this.querySelector(`[data-selected-swatch-value="${name}"]`);
        if (selectedSwatchValue) selectedSwatchValue.innerHTML = value;
      }
    }

    getVariantMedia() {
      if (!this.currentVariant) return null;
      return this.currentVariant.featured_media || this.currentVariant.featured_image || null;
    }

    updateMedia() {
      const media = this.getVariantMedia();
      const mediaGalleries = document.querySelectorAll(
        `media-gallery[data-section="${this.dataset.section}"], [id^="MediaGallery-${this.dataset.section}"]`
      );

      mediaGalleries.forEach((mediaGallery) => {
        if (typeof mediaGallery.setActiveMedia !== 'function') return;

        const hasFiltering =
          this.dataset.hasFiltering === 'true' || Boolean(mediaGallery.dataset.filteringOption);

        let mediaId = null;
        if (media?.id) {
          mediaId = `${this.dataset.section}-${media.id}`;
        } else if (hasFiltering) {
          // After filtering, jump to first visible slide for this option group.
          const filterKey = mediaGallery.dataset.filteringOption;
          const optionValue = filterKey ? this.currentVariant?.[filterKey] : null;
          const firstVisible = Array.from(
            mediaGallery.querySelectorAll('.product__media-item')
          ).find((slide) => {
            if (!optionValue) return !slide.classList.contains('hidden');
            return slide.dataset.alt === optionValue || slide.dataset.alt === 'always_display';
          });
          mediaId = firstVisible?.dataset?.mediaId || null;
        }

        if (!mediaId && !hasFiltering) return;
        mediaGallery.setActiveMedia(mediaId, true, hasFiltering, this.currentVariant);
      });

      if (!media?.id) return;
      const modalContent = document.querySelector(
        `#ProductModal-${this.dataset.section} .product-media-modal__content`
      );
      if (!modalContent) return;
      const newMediaModal = modalContent.querySelector(`[data-media-id="${media.id}"]`);
      if (newMediaModal) modalContent.prepend(newMediaModal);
    }

    updateURL() {
      if (!this.currentVariant || this.dataset.updateUrl === 'false') return;
      window.history.replaceState({}, '', `${this.dataset.url}?variant=${this.currentVariant.id}`);
    }

    updateShareUrl() {
      const shareButton = document.getElementById(`Share-${this.dataset.section}`);
      if (!shareButton || !shareButton.updateUrl) return;
      shareButton.updateUrl(`${window.shopUrl}${this.dataset.url}?variant=${this.currentVariant.id}`);
    }

    updateVariantInput() {
      const productForms = document.querySelectorAll(
        `#product-form-${this.dataset.section}, #product-form-installment-${this.dataset.section}, product-form[data-section="${this.dataset.section}"] form`
      );
      productForms.forEach((productForm) => {
        const input = productForm.querySelector('input[name="id"]');
        if (!input) return;
        input.value = this.currentVariant.id;
        input.dispatchEvent(new Event('change', { bubbles: true }));
      });
    }

    updateVariantStatuses() {
      const checked = this.querySelector(':checked');
      if (!checked) return;
      const selectedOptionOneVariants = this.variantData.filter(
        (variant) => checked.value === variant.option1
      );
      const inputWrappers = [...this.querySelectorAll('.product-form__input')];
      inputWrappers.forEach((option, index) => {
        if (index === 0) return;
        const optionInputs = [...option.querySelectorAll('input[type="radio"], option')];
        const previousOptionSelected = inputWrappers[index - 1].querySelector(':checked')?.value;
        const availableOptionInputsValue = selectedOptionOneVariants
          .filter((variant) => variant.available && variant[`option${index}`] === previousOptionSelected)
          .map((variantOption) => variantOption[`option${index + 1}`]);
        this.setInputAvailability(optionInputs, availableOptionInputsValue);
      });
    }

    setInputAvailability(elementList, availableValuesList) {
      elementList.forEach((element) => {
        const value = element.getAttribute('value');
        const availableElement = availableValuesList.includes(value);
        if (element.tagName === 'INPUT') {
          element.classList.toggle('disabled', !availableElement);
        } else if (element.tagName === 'OPTION') {
          element.innerText = availableElement
            ? value
            : window.variantStrings.unavailable_with_option.replace('[value]', value);
        }
      });
    }

    updatePickupAvailability() {
      const pickUpAvailability = document.querySelector('pickup-availability');
      if (!pickUpAvailability) return;
      if (this.currentVariant && this.currentVariant.available) {
        pickUpAvailability.fetchAvailability(this.currentVariant.id);
      } else {
        pickUpAvailability.removeAttribute('available');
        pickUpAvailability.innerHTML = '';
      }
    }

    removeErrorMessage() {
      const section = this.closest('section');
      if (!section) return;
      const productForm = section.querySelector('product-form');
      if (productForm) productForm.handleErrorMessage();
    }

    renderProductInfo() {
      const requestedVariantId = this.currentVariant.id;
      const sectionId = this.dataset.originalSection ? this.dataset.originalSection : this.dataset.section;

      fetch(
        `${this.dataset.url}?variant=${requestedVariantId}&section_id=${sectionId}`
      )
        .then((response) => response.text())
        .then((responseText) => {
          if (this.currentVariant.id !== requestedVariantId) return;
          const html = new DOMParser().parseFromString(responseText, 'text/html');
          const destination = document.getElementById(`price-${this.dataset.section}`);
          const source = html.getElementById(`price-${sectionId}`);
          if (source && destination) destination.innerHTML = source.innerHTML;

          const skuSource = html.getElementById(`Sku-${sectionId}`);
          const skuDestination = document.getElementById(`Sku-${this.dataset.section}`);
          if (skuSource && skuDestination) {
            skuDestination.innerHTML = skuSource.innerHTML;
            skuDestination.classList.toggle('hidden', skuSource.classList.contains('hidden'));
          }

          const inventorySource = html.getElementById(`Inventory-${sectionId}`);
          const inventoryDestination = document.getElementById(`Inventory-${this.dataset.section}`);
          if (inventorySource && inventoryDestination) {
            inventoryDestination.innerHTML = inventorySource.innerHTML;
            inventoryDestination.classList.toggle('hidden', inventorySource.innerText === '');
          }

          const price = document.getElementById(`price-${this.dataset.section}`);
          if (price) price.classList.remove('hidden');

          const addButtonUpdated = html.getElementById(`ProductSubmitButton-${sectionId}`);
          this.toggleAddButton(
            addButtonUpdated ? addButtonUpdated.hasAttribute('disabled') : true,
            window.variantStrings.soldOut
          );

          publish(PUB_SUB_EVENTS.variantChange, {
            data: { sectionId, html, variant: this.currentVariant },
          });
        });
    }

    toggleAddButton(disable = true, text, modifyClass = true) {
      const productForm =
        document.getElementById(`product-form-${this.dataset.section}`) ||
        document.querySelector(`product-form[data-section="${this.dataset.section}"] form`);
      if (!productForm) return;
      const addButton = productForm.querySelector('[name="add"]');
      const addButtonText =
        productForm.querySelector('[name="add"] > span') ||
        productForm.querySelector('[name="add"] .main-atc__label__line-1') ||
        productForm.querySelector('[name="add"] .button__label');
      if (!addButton) return;

      if (disable) {
        addButton.setAttribute('disabled', 'disabled');
        if (text && addButtonText) addButtonText.textContent = text;
      } else {
        addButton.removeAttribute('disabled');
        if (addButtonText) addButtonText.textContent = window.variantStrings.addToCart;
      }
      if (!modifyClass) return;
    }

    setUnavailable() {
      const button =
        document.getElementById(`product-form-${this.dataset.section}`) ||
        document.querySelector(`product-form[data-section="${this.dataset.section}"] form`);
      if (!button) return;
      const addButton = button.querySelector('[name="add"]');
      const addButtonText =
        button.querySelector('[name="add"] > span') ||
        button.querySelector('[name="add"] .main-atc__label__line-1') ||
        button.querySelector('[name="add"] .button__label');
      if (!addButton) return;
      if (addButtonText) addButtonText.textContent = window.variantStrings.unavailable;
      const price = document.getElementById(`price-${this.dataset.section}`);
      if (price) price.classList.add('hidden');
    }

    getVariantData() {
      this.variantData =
        this.variantData || JSON.parse(this.querySelector('[type="application/json"]').textContent);
      return this.variantData;
    }
  }

  customElements.define('variant-selects', VariantSelects);
}

if (!customElements.get('card-variant-selects') && customElements.get('variant-selects')) {
  customElements.define(
    'card-variant-selects',
    class CardVariantSelects extends customElements.get('variant-selects') {}
  );
}

if (!customElements.get('promo-popup')) {
  customElements.define(
    'promo-popup',
    class PromoPopup extends HTMLElement {
      connectedCallback() {
        this.overlay = this.querySelector('.sign-up-popup-overlay');
        this.modal = this.querySelector('.sign-up-popup-modal');
        this.closeButtons = this.querySelectorAll('.promp-popup__close-btn');
        this.storageKey = `promo-popup-${window.location.host}`;
        this.testMode = this.dataset.testMode === 'true';
        this.delayDays = parseInt(this.dataset.delayDays || '7', 10);
        this.delaySeconds = parseInt(this.dataset.delaySeconds || '0', 10) * 1000;

        this.closeButtons.forEach((btn) => btn.addEventListener('click', () => this.close(true)));
        if (this.overlay) this.overlay.addEventListener('click', () => this.close(true));

        if (this.testMode) {
          this.open();
          return;
        }

        try {
          const saved = JSON.parse(localStorage.getItem(this.storageKey) || 'null');
          if (saved?.closedAt) {
            const days = (Date.now() - saved.closedAt) / (1000 * 60 * 60 * 24);
            if (days < this.delayDays) return;
          }
        } catch (e) {}

        setTimeout(() => this.open(), Math.max(0, this.delaySeconds));
      }

      open() {
        this.overlay?.classList.add('popup-overlay--active');
        this.modal?.classList.add('popup-modal--active');
      }

      close(persist) {
        this.overlay?.classList.remove('popup-overlay--active');
        this.modal?.classList.remove('popup-modal--active');
        if (persist && !this.testMode) {
          localStorage.setItem(this.storageKey, JSON.stringify({ closedAt: Date.now() }));
        }
      }
    }
  );
}

if (!customElements.get('subscription-widget')) {
  customElements.define('subscription-widget', class SubscriptionWidget extends HTMLElement {});
}
