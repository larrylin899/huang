(() => {
  const initialized = new WeakSet();
  function setup(root = document) {
    root.querySelectorAll('[data-pp-header]').forEach(header => {
      if (initialized.has(header)) return;
      initialized.add(header);
      let opener;
      header.querySelectorAll('[data-pp-open]').forEach(button => button.addEventListener('click', () => {
        const dialog = header.querySelector(`[data-pp-dialog="${button.dataset.ppOpen}"]`);
        if (!dialog || dialog.open) return;
        opener = button;
        dialog.showModal(); button.setAttribute('aria-expanded', 'true');
        if (button.dataset.ppOpen === 'search') dialog.querySelector('input[type="search"]')?.focus();
      }));
      header.querySelectorAll('[data-pp-dialog]').forEach(dialog => {
        dialog.querySelector('[data-pp-close]')?.addEventListener('click', () => dialog.close());
        dialog.addEventListener('click', event => {
          const rect = dialog.getBoundingClientRect();
          if (event.target === dialog && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) dialog.close();
        });
        dialog.addEventListener('close', () => { opener?.setAttribute('aria-expanded', 'false'); opener?.focus(); });
      });
      header.querySelectorAll('.pp-mega').forEach(details => details.addEventListener('toggle', () => {
        if (details.open) header.querySelectorAll('.pp-mega').forEach(other => { if (other !== details) other.open = false; });
      }));
      header.addEventListener('keydown', event => {
        if (event.key === 'Escape') header.querySelectorAll('.pp-mega[open]').forEach(details => { details.open = false; details.querySelector('summary')?.focus(); });
      });
    });
    root.querySelectorAll('[data-pp-categories]').forEach(section => {
      if (initialized.has(section)) return;
      initialized.add(section);
      const activate = link => {
        section.querySelectorAll('[data-pp-category]').forEach(other => other.classList.toggle('is-active', other === link));
        section.querySelectorAll('[data-pp-frame]').forEach(frame => frame.classList.toggle('is-active', frame.dataset.ppFrame === link.dataset.ppCategory));
      };
      section.querySelectorAll('[data-pp-category]').forEach(link => {
        link.addEventListener('pointerenter', () => activate(link));
        link.addEventListener('focus', () => activate(link));
      });
    });
    root.querySelectorAll('.pp-products').forEach(section => {
      if (initialized.has(section)) return;
      initialized.add(section);
      const rail = section.querySelector('[data-pp-rail]');
      if (!rail) return;
      const move = direction => rail.scrollBy({ left: direction * rail.clientWidth * .8, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' });
      section.querySelector('[data-pp-prev]')?.addEventListener('click', () => move(-1));
      section.querySelector('[data-pp-next]')?.addEventListener('click', () => move(1));
    });
    root.querySelectorAll('.pp-footer').forEach(footer => {
      if (initialized.has(footer)) return;
      initialized.add(footer);
      const media = matchMedia('(max-width: 749px)');
      const sync = () => footer.querySelectorAll('[data-pp-footer-detail]').forEach(details => { details.open = !media.matches; });
      sync(); media.addEventListener('change', sync);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setup()); else setup();
  document.addEventListener('shopify:section:load', () => setup());
  document.addEventListener('cart:update', event => {
    const count = event.detail?.resource?.item_count;
    if (typeof count !== 'number') return;
    document.querySelectorAll('[data-pp-count]').forEach(badge => { badge.textContent = String(count); badge.hidden = count === 0; });
  });
})();
document.addEventListener('click',event=>{const button=event.target.closest('[data-pp-pause]');if(!button)return;const track=button.closest('.pp-ticker')?.querySelector('[data-pp-ticker]');if(!track)return;const paused=track.classList.toggle('is-paused');button.setAttribute('aria-pressed',String(paused));button.setAttribute('aria-label',paused?'Resume scrolling messages':'Pause scrolling messages');button.textContent=paused?'▶':'Ⅱ';});
